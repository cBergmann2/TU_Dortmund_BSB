/*****************************************************************************/
/* Betriebssysteme                                                           */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                         C U S T O M E R                                   */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Ein Thread, der auf ein Ereignis warten kann.                             */
/*****************************************************************************/

#ifndef __customer_include__
#define __customer_include__

/* Hier muesst ihr selbst Code vervollstaendigen */ 
        
class Customer 
/* Hier muesst ihr selbst Code vervollstaendigen */         
 {
private:
    Customer (const Customer &copy); // Verhindere Kopieren
/* Hier muesst ihr selbst Code vervollstaendigen */          
};

#endif
