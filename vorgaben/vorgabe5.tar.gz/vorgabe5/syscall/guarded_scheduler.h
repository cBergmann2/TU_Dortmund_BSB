/*****************************************************************************/
/* Betriebssysteme                                                           */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                   G U A R D E D _ S C H E D U L E R                       */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/* Systemaufrufschnittstelle zum Scheduler.                                  */
/*****************************************************************************/

#ifndef __guarded_scheduler_include__
#define __guarded_scheduler_include__

/* Hier muesst ihr selbst Code vervollstaendigen */ 
        
class Guarded_Scheduler 
/* Hier muesst ihr selbst Code vervollstaendigen */         
 {
private:
      Guarded_Scheduler (const Guarded_Scheduler &copy); // Verhindere Kopieren
public:
      Guarded_Scheduler () {}
/* Hier muesst ihr selbst Code vervollstaendigen */          
 };

#endif
